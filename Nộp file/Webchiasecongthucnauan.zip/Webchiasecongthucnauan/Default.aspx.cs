﻿using System;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Webchiasecongthucnauan
{
    public partial class Default : System.Web.UI.Page
    {
        string connString = ConfigurationManager.ConnectionStrings["ChuoiKetNoi"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Lấy tham số từ URL (nếu có lọc danh mục hoặc tìm kiếm)
                string maDM = Request.QueryString["MaDM"];
                string tuKhoa = Request.QueryString["timKiem"];

                using (SqlConnection conn = new SqlConnection(connString))
                {
                    string query = "";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;

                    if (!string.IsNullOrEmpty(maDM))
                    {
                        // 1. Trường hợp người dùng bấm lọc theo danh mục
                        query = "SELECT * FROM CongThuc WHERE MaDM = @MaDM ORDER BY MaCT DESC";
                        cmd.Parameters.AddWithValue("@MaDM", maDM);
                    }
                    else if (!string.IsNullOrEmpty(tuKhoa))
                    {
                        // 2. Trường hợp người dùng nhập từ khóa tìm kiếm
                        query = "SELECT * FROM CongThuc WHERE TenMon LIKE @TuKhoa ORDER BY MaCT DESC";
                        cmd.Parameters.AddWithValue("@TuKhoa", "%" + tuKhoa + "%");

                        // Giữ lại từ khóa trên ô textbox cho người dùng thấy
                        txtTuKhoa.Text = tuKhoa;
                    }
                    else
                    {
                        // 3. Trường hợp mặc định (Hiển thị tất cả món ăn)
                        query = "SELECT * FROM CongThuc ORDER BY MaCT DESC";
                    }

                    cmd.CommandText = query;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    rptCongThuc.DataSource = dt;
                    rptCongThuc.DataBind();
                }
            }
        }

        // Sự kiện khi người dùng bấm nút Tìm kiếm
        protected void btnTimKiem_Click(object sender, EventArgs e)
        {
            string tuKhoa = txtTuKhoa.Text.Trim();
            // Chuyển hướng kèm theo từ khóa lên URL
            Response.Redirect("Default.aspx?timKiem=" + Server.UrlEncode(tuKhoa));
        }
    }
}